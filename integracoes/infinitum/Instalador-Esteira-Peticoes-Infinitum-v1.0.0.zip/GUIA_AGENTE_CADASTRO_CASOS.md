# Guia do agente — criar ou completar o cadastro Casos

A API pública do Infinitum lista cadastros e registros, mas em 02/set/2026 as
rotas públicas tentadas para criar/editar os campos do cadastro responderam 404.
Por isso, somente esta etapa usa a interface autenticada.

## Procedimento

1. Abra `https://crm.infinitum.app.br/cadastros` na sessão já autenticada.
2. Localize `Casos`. Se não existir, crie um cadastro exatamente com esse nome.
3. Abra a configuração do cadastro e compare com `cases_database.fields` em
   `manifesto.json`.
4. Acrescente apenas os campos ausentes. Se um campo homônimo tiver tipo errado,
   preserve os dados e ajuste pela interface quando ela permitir; não o exclua.
5. Em `Cliente vinculado`, use vínculo de cadastro, selecione `Clientes`, permita
   somente um registro e marque obrigatório.
6. Reproduza as opções de `Área jurídica`, `Polo do cliente` e `Status do caso`
   exatamente como estão no manifesto.
7. Salve e rode `python3 instalar.py` novamente. O próprio instalador valida os
   nomes, tipos e obrigatoriedade antes de alterar o procedimento.

## Registro sintético para a prova

Se não houver um registro claramente fictício, crie pela interface:

- cliente: `[TESTE] Cliente da instalação`;
- caso: `[TESTE] Caso da instalação`;
- número: `0000000-00.0000.0.00.0000`;
- área: `Outro`;
- status: `Ativo`.

Copie o ID do registro de `Casos` a partir da URL ou da resposta da API e use em
`--test-case-record-id`. Deixe o cliente, caso e card sintéticos na conta para o
aluno estudar. Não use nome, processo ou documento verdadeiro.
