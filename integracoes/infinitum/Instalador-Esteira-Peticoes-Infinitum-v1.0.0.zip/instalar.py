#!/usr/bin/env python3
"""Instalador idempotente da Esteira de Petições no Infinitum.

Usa somente a API pública documentada. Não apaga POPs, fases, campos, cards,
cadastros ou automações. A estrutura do cadastro Casos é validada, mas precisa
ser criada pela interface porque a API pública não expõe essa mutação.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
MANIFEST_PATH = ROOT / "manifesto.json"
DEFAULT_OUTPUT = ROOT / "resultado_instalacao.json"


class InstallError(RuntimeError):
    exit_code = 1


class NeedsUI(InstallError):
    exit_code = 20


class NeedsChoice(InstallError):
    exit_code = 21


def norm(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    return " ".join("".join(ch for ch in text if not unicodedata.combining(ch)).lower().split())


def unwrap_data(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def unwrap_list(payload: Any, *fallback_keys: str) -> list[dict[str, Any]]:
    current = unwrap_data(payload)
    if isinstance(current, list):
        return current
    if isinstance(current, dict):
        for key in fallback_keys:
            value = current.get(key)
            if isinstance(value, list):
                return value
        if isinstance(current.get("data"), list):
            return current["data"]
    return []


class InfinitumAPI:
    def __init__(self, base_url: str, token: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.token = token.strip()
        self.timeout = timeout
        self.ssl_context = self._ssl_context()

    @staticmethod
    def _ssl_context() -> ssl.SSLContext:
        try:
            import certifi  # type: ignore

            return ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            return ssl.create_default_context()

    def request(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        url = f"{self.base_url}{path}"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        request = urllib.request.Request(
            url,
            method=method,
            data=data,
            headers={
                "X-Public-Token": self.token,
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "Instalador-Esteira-Infinitum/1.0",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout, context=self.ssl_context) as response:
                raw = response.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:1000]
            raise InstallError(f"Infinitum respondeu HTTP {exc.code} em {method} {path}: {detail}") from exc
        except urllib.error.URLError as exc:
            if "CERTIFICATE_VERIFY_FAILED" in str(exc) and shutil.which("curl"):
                return self._request_with_curl(method, url, body)
            raise InstallError(f"Falha de rede em {method} {path}: {exc}") from exc

    def _request_with_curl(self, method: str, url: str, body: dict[str, Any] | None) -> Any:
        header_file = tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", delete=False)
        body_file = None
        try:
            os.chmod(header_file.name, 0o600)
            header_file.write(f"X-Public-Token: {self.token}\nAccept: application/json\nContent-Type: application/json\n")
            header_file.close()
            command = [
                "curl",
                "--silent",
                "--show-error",
                "--fail-with-body",
                "--request",
                method,
                "--header",
                f"@{header_file.name}",
                "--max-time",
                str(self.timeout),
            ]
            if body is not None:
                body_file = tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", delete=False)
                os.chmod(body_file.name, 0o600)
                json.dump(body, body_file, ensure_ascii=False)
                body_file.close()
                command.extend(["--data-binary", f"@{body_file.name}"])
            command.append(url)
            completed = subprocess.run(command, capture_output=True, text=True, timeout=self.timeout + 5)
            if completed.returncode:
                raise InstallError(f"Infinitum recusou {method} {url}: {completed.stderr.strip() or completed.stdout[:1000]}")
            return json.loads(completed.stdout) if completed.stdout.strip() else {}
        finally:
            Path(header_file.name).unlink(missing_ok=True)
            if body_file is not None:
                Path(body_file.name).unlink(missing_ok=True)

    def get(self, path: str) -> Any:
        return self.request("GET", path)

    def post(self, path: str, body: dict[str, Any]) -> Any:
        return self.request("POST", path, body)

    def put(self, path: str, body: dict[str, Any]) -> Any:
        return self.request("PUT", path, body)


@dataclass
class InstallContext:
    organization: dict[str, Any]
    cases_database: dict[str, Any]
    pop: dict[str, Any]
    phases: dict[str, dict[str, Any]]
    fields: dict[str, dict[str, Any]]
    automations: dict[str, dict[str, Any]]
    test_card: dict[str, Any] | None = None


class Installer:
    def __init__(
        self,
        api: InfinitumAPI,
        manifest: dict[str, Any],
        *,
        organization_id: str = "",
        organization_name: str = "",
        cases_database_id: str = "",
        pop_name: str = "",
        automation_prefix: str = "[ESTEIRA]",
        verify_only: bool = False,
    ):
        self.api = api
        self.manifest = manifest
        self.organization_id = organization_id
        self.organization_name = organization_name
        self.cases_database_id = cases_database_id
        self.pop_name = pop_name or manifest["pop"]["name"]
        self.automation_prefix = automation_prefix.strip()
        self.verify_only = verify_only
        self.actions: list[str] = []
        self.available_databases: list[dict[str, Any]] = []

    def run(self, test_case_record_id: str = "", test_case_title: str = "Caso fictício da instalação") -> InstallContext:
        organization = self._select_organization()
        org_id = organization["id"]
        cases_database = self._find_cases_database(org_id)
        self._validate_cases_schema(cases_database)
        pop = self._ensure_pop(org_id)
        phases = self._ensure_phases(org_id, pop["id"])
        fields = self._ensure_fields(org_id, pop["id"], cases_database["id"], phases)
        automations = self._ensure_automations(org_id, pop["id"], phases, fields)
        context = InstallContext(organization, cases_database, pop, phases, fields, automations)
        if test_case_record_id:
            if self.verify_only:
                raise InstallError("--test-case-record-id não pode ser combinado com --verify-only")
            context.test_card = self._ensure_test_card(
                org_id,
                pop["id"],
                cases_database["id"],
                phases,
                fields,
                test_case_record_id,
                test_case_title,
            )
        return context

    def _select_organization(self) -> dict[str, Any]:
        organizations = unwrap_list(self.api.get("/organizations/my"), "organizations")
        if not organizations:
            raise InstallError("O token não devolveu nenhuma organização do Infinitum.")
        if self.organization_id:
            matches = [item for item in organizations if item.get("id") == self.organization_id]
        elif self.organization_name:
            matches = [item for item in organizations if norm(item.get("name")) == norm(self.organization_name)]
        elif len(organizations) == 1:
            matches = organizations
        else:
            choices = ", ".join(f"{item.get('name')} ({item.get('id')})" for item in organizations)
            raise NeedsChoice(f"O token acessa mais de uma organização. Execute novamente com --organization-id. Opções: {choices}")
        if len(matches) != 1:
            raise InstallError("Não foi possível identificar exatamente uma organização com os parâmetros informados.")
        return matches[0]

    def _find_cases_database(self, org_id: str) -> dict[str, Any]:
        query = urllib.parse.urlencode({"organization_id": org_id})
        databases = unwrap_list(self.api.get(f"/databases?{query}"), "databases")
        self.available_databases = databases
        if self.cases_database_id:
            matches = [item for item in databases if item.get("id") == self.cases_database_id]
        else:
            wanted = norm(self.manifest["cases_database"]["name"])
            matches = [item for item in databases if norm(item.get("name")) == wanted]
        if not matches:
            raise NeedsUI(
                "UI_REQUIRED: o cadastro 'Casos' não existe. O agente deve criá-lo pela interface conforme "
                "GUIA_AGENTE_CADASTRO_CASOS.md e executar o instalador novamente."
            )
        if len(matches) > 1:
            choices = ", ".join(f"{item.get('name')} ({item.get('id')})" for item in matches)
            raise NeedsChoice(f"Há mais de um cadastro chamado Casos. Use --casos-database-id. Opções: {choices}")
        return matches[0]

    def _validate_cases_schema(self, database: dict[str, Any]) -> None:
        query = urllib.parse.urlencode({"database_id": database["id"]})
        fields = unwrap_list(self.api.get(f"/database-fields?{query}"), "fields", "database_fields")
        expected = self.manifest["cases_database"]["fields"]
        missing: list[str] = []
        conflicts: list[str] = []
        for spec in expected:
            matches = [item for item in fields if norm(item.get("label")) == norm(spec["label"])]
            if not matches:
                missing.append(spec["label"])
                continue
            actual = matches[0]
            if actual.get("type") != spec["type"]:
                conflicts.append(f"{spec['label']}: tipo {actual.get('type')} em vez de {spec['type']}")
            if bool(actual.get("required")) != bool(spec["required"]):
                conflicts.append(f"{spec['label']}: obrigatório={actual.get('required')} em vez de {spec['required']}")
            actual_options = actual.get("options") or {}
            if spec["type"] == "select":
                wanted_options = spec.get("options") or []
                if actual_options.get("options") != wanted_options:
                    conflicts.append(f"{spec['label']}: opções diferentes do manifesto")
            elif spec["type"] == "database":
                linked_name = spec.get("linked_database")
                linked_matches = [
                    item for item in self.available_databases if norm(item.get("name")) == norm(linked_name)
                ]
                if len(linked_matches) != 1:
                    conflicts.append(f"{spec['label']}: cadastro de destino '{linked_name}' não identificado")
                elif actual_options.get("linked_database_id") != linked_matches[0].get("id"):
                    conflicts.append(f"{spec['label']}: não aponta para o cadastro '{linked_name}'")
                if bool(actual_options.get("allow_multiple", False)):
                    conflicts.append(f"{spec['label']}: permite múltiplos registros")
        if missing or conflicts:
            details = []
            if missing:
                details.append("faltam: " + ", ".join(missing))
            if conflicts:
                details.append("divergências: " + "; ".join(conflicts))
            raise NeedsUI(
                "UI_REQUIRED: o cadastro Casos existe, mas precisa ser completado pela interface ("
                + " | ".join(details)
                + "). Siga GUIA_AGENTE_CADASTRO_CASOS.md e execute novamente."
            )
        self.actions.append("Cadastro Casos validado")

    def _ensure_pop(self, org_id: str) -> dict[str, Any]:
        pops = unwrap_list(self.api.get(f"/organizations/{org_id}/pops?is_active=true&limit=100"), "pops")
        matches = [item for item in pops if norm(item.get("name")) == norm(self.pop_name)]
        if len(matches) > 1:
            raise InstallError(f"Há mais de um procedimento chamado '{self.pop_name}'. Não alterei nenhum deles.")
        if matches:
            self.actions.append("Procedimento reutilizado")
            return matches[0]
        if self.verify_only:
            raise InstallError(f"Procedimento ausente: {self.pop_name}")
        spec = dict(self.manifest["pop"])
        spec["name"] = self.pop_name
        created = unwrap_data(self.api.post(f"/organizations/{org_id}/pops", spec))
        self.actions.append("Procedimento criado")
        return created

    def _ensure_phases(self, org_id: str, pop_id: str) -> dict[str, dict[str, Any]]:
        phases = unwrap_list(self.api.get(f"/pops/{pop_id}/phases"), "phases")
        result: dict[str, dict[str, Any]] = {}
        for spec in self.manifest["phases"]:
            matches = [item for item in phases if norm(item.get("name")) == norm(spec["name"])]
            if len(matches) > 1:
                raise InstallError(f"Fase duplicada no procedimento: {spec['name']}")
            if matches:
                result[spec["name"]] = matches[0]
                continue
            if self.verify_only:
                raise InstallError(f"Fase ausente: {spec['name']}")
            body = {"organization_id": org_id, "allow_direct_cards": True, **spec}
            created = unwrap_data(self.api.post(f"/pops/{pop_id}/phases", body))
            if not any(item.get("id") == created.get("id") for item in phases):
                phases.append(created)
            result[spec["name"]] = created
            self.actions.append(f"Fase criada: {spec['name']}")
        return result

    def _ensure_fields(
        self,
        org_id: str,
        pop_id: str,
        cases_database_id: str,
        phases: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        fields = unwrap_list(self.api.get(f"/pop-fields/by-pop?pop_id={pop_id}&page=1&limit=100"), "fields")
        used_slugs = {str(item.get("field_id")) for item in fields}
        result: dict[str, dict[str, Any]] = {}
        for spec in self.manifest["fields"]:
            phase_id = phases[spec["phase"]]["id"]
            matches = [
                item
                for item in fields
                if item.get("phase_id") == phase_id and norm(item.get("label")) == norm(spec["label"])
            ]
            if len(matches) > 1:
                raise InstallError(f"Campo duplicado na fase {spec['phase']}: {spec['label']}")
            if matches:
                actual = matches[0]
                self._validate_pop_field(actual, spec, cases_database_id)
                result[spec["field_id"]] = actual
                continue
            if self.verify_only:
                raise InstallError(f"Campo ausente em {spec['phase']}: {spec['label']}")
            slug = spec["field_id"]
            suffix = 2
            while slug in used_slugs:
                slug = f"{spec['field_id']}_{suffix}"
                suffix += 1
            body: dict[str, Any] = {
                "organization_id": org_id,
                "pop_id": pop_id,
                "phase_id": phase_id,
                "field_id": slug,
                "label": spec["label"],
                "type": spec["type"],
                "required": spec["required"],
                "position": spec["position"],
            }
            if spec["type"] == "select":
                body["options"] = {"options": spec["options"]}
            elif spec["type"] == "database":
                body["options"] = {
                    "database_id": cases_database_id,
                    "allow_multiple": bool(spec.get("allow_multiple", False)),
                }
            created = unwrap_data(self.api.post("/pop-fields", body))
            if not any(item.get("id") == created.get("id") for item in fields):
                fields.append(created)
            used_slugs.add(slug)
            result[spec["field_id"]] = created
            self.actions.append(f"Campo criado: {spec['label']}")
        return result

    @staticmethod
    def _validate_pop_field(actual: dict[str, Any], spec: dict[str, Any], cases_database_id: str) -> None:
        problems = []
        if actual.get("type") != spec["type"]:
            problems.append(f"tipo={actual.get('type')}")
        if bool(actual.get("required")) != bool(spec["required"]):
            problems.append(f"obrigatório={actual.get('required')}")
        if spec["type"] == "database":
            options = actual.get("options") or {}
            if options.get("database_id") != cases_database_id:
                problems.append("aponta para outro cadastro")
            if bool(options.get("allow_multiple", False)):
                problems.append("permite múltiplos casos")
        if problems:
            raise InstallError(
                f"O campo '{spec['label']}' já existe, mas está incompatível ({', '.join(problems)}). "
                "A API não oferece edição segura desse campo; corrija-o pela interface sem apagar dados."
            )

    def _automation_name(self, suffix: str) -> str:
        return f"{self.automation_prefix} {suffix}".strip()

    def _desired_automations(
        self,
        org_id: str,
        pop_id: str,
        phases: dict[str, dict[str, Any]],
        fields: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        case_field = fields["caso_vinculado"]
        case_name = self._automation_name("Caso vinculado preenchido → análise")
        review_name = self._automation_name("Ao entrar em revisão, criar tarefa humana")
        return {
            "case_to_analysis": {
                "organization_id": org_id,
                "pop_id": pop_id,
                "name": case_name,
                "description": "O vínculo com a ficha-mãe Casos é o comando seguro para iniciar a análise.",
                "is_active": True,
                "workflow": {
                    "version": "1.0",
                    "nodes": [
                        {
                            "id": "trigger-case-link",
                            "type": "trigger",
                            "triggerType": "field_updated",
                            "config": {
                                "fieldConditions": [
                                    {
                                        "fieldId": case_field["id"],
                                        "fieldLabel": case_field["label"],
                                        "operator": "not_empty",
                                        "value": "",
                                    }
                                ],
                                "fieldId": case_field["id"],
                                "fieldIds": [case_field["id"]],
                                "fieldLabel": case_field["label"],
                                "fieldLabels": [case_field["label"]],
                                "fieldsMatchMode": "any",
                                "operator": "not_empty",
                                "value": "",
                            },
                            "position": {"x": 100, "y": 100},
                        },
                        {
                            "id": "action-move-analysis",
                            "type": "action",
                            "actionType": "move_card",
                            "config": {
                                "fieldMappings": [],
                                "targetPhaseId": phases["Em análise pela IA"]["id"],
                                "targetPhaseName": "Em análise pela IA",
                                "titleFieldId": None,
                            },
                            "position": {"x": 400, "y": 100},
                        },
                    ],
                    "edges": [
                        {"id": "edge-case-analysis", "source": "trigger-case-link", "target": "action-move-analysis"}
                    ],
                },
            },
            "review_task": {
                "organization_id": org_id,
                "pop_id": pop_id,
                "name": review_name,
                "description": "Cria uma tarefa humana sempre que uma minuta entra em Revisão humana.",
                "is_active": True,
                "workflow": {
                    "version": "1.0",
                    "nodes": [
                        {
                            "id": "trigger-review",
                            "type": "trigger",
                            "triggerType": "phase_changed",
                            "config": {"phaseId": phases["Revisão humana"]["id"], "direction": "entered"},
                            "position": {"x": 100, "y": 100},
                        },
                        {
                            "id": "action-review-task",
                            "type": "action",
                            "actionType": "create_task",
                            "config": {
                                "title": "Revisar minuta e registrar decisão estruturada",
                                "level": "card",
                            },
                            "position": {"x": 400, "y": 100},
                        },
                    ],
                    "edges": [
                        {"id": "edge-review", "source": "trigger-review", "target": "action-review-task"}
                    ],
                },
            },
        }

    def _ensure_automations(
        self,
        org_id: str,
        pop_id: str,
        phases: dict[str, dict[str, Any]],
        fields: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        query = urllib.parse.urlencode({"organization_id": org_id, "pop_id": pop_id, "limit": 100})
        existing = unwrap_list(self.api.get(f"/pop-automations?{query}"), "automations")
        desired = self._desired_automations(org_id, pop_id, phases, fields)
        result: dict[str, dict[str, Any]] = {}
        for key, spec in desired.items():
            matches = [item for item in existing if norm(item.get("name")) == norm(spec["name"])]
            if len(matches) > 1:
                raise InstallError(f"Automação duplicada: {spec['name']}")
            if not matches:
                if self.verify_only:
                    raise InstallError(f"Automação ausente: {spec['name']}")
                created = unwrap_data(self.api.post("/pop-automations", spec))
                result[key] = created
                self.actions.append(f"Automação criada: {spec['name']}")
                continue
            item = matches[0]
            detail_query = urllib.parse.urlencode({"organization_id": org_id})
            detail = unwrap_data(self.api.get(f"/pop-automations/{item['id']}?{detail_query}"))
            comparable_actual = {
                "name": detail.get("name"),
                "description": detail.get("description") or "",
                "is_active": bool(detail.get("is_active")),
                "workflow": detail.get("workflow"),
            }
            comparable_desired = {
                "name": spec["name"],
                "description": spec.get("description") or "",
                "is_active": True,
                "workflow": spec["workflow"],
            }
            if comparable_actual != comparable_desired:
                if self.verify_only:
                    raise InstallError(f"Automação divergente: {spec['name']}")
                updated = unwrap_data(self.api.put(f"/pop-automations/{item['id']}", spec))
                result[key] = updated
                self.actions.append(f"Automação atualizada: {spec['name']}")
            else:
                result[key] = detail
        return result

    def _ensure_test_card(
        self,
        org_id: str,
        pop_id: str,
        cases_database_id: str,
        phases: dict[str, dict[str, Any]],
        fields: dict[str, dict[str, Any]],
        case_record_id: str,
        case_title: str,
    ) -> dict[str, Any]:
        query = urllib.parse.urlencode({"organization_id": org_id, "pop_id": pop_id, "page": 1, "limit": 100})
        cards = unwrap_list(self.api.get(f"/cards?{query}"), "cards")
        title = "[TESTE INSTALAÇÃO] Caso vinculado → análise"
        matches = [item for item in cards if item.get("title") == title]
        if matches:
            card = matches[0]
            self.actions.append("Card sintético de validação reutilizado")
        else:
            body = {
                "organization_id": org_id,
                "pop_id": pop_id,
                "phase_id": phases["Entrada validada"]["id"],
                "title": title,
                "priority": "low",
                "values": [
                    {"field_id": fields["id_externo"]["id"], "value": "INSTALACAO-ESTEIRA-V1"},
                    {"field_id": fields["numero_processo"]["id"], "value": "0000000-00.0000.0.00.0000"},
                    {"field_id": fields["tipo_peca"]["id"], "value": "Manifestação"},
                ],
            }
            card = unwrap_data(self.api.post("/cards", body))
            self.actions.append("Card sintético de validação criado")

        current = unwrap_data(self.api.get(f"/cards/{card['id']}"))
        if current.get("phase_id") != phases["Em análise pela IA"]["id"]:
            # O gatilho field_updated não dispara quando o card já nasce com o
            # valor. Para reproduzir a interface, primeiro garantimos uma
            # alteração vazia e depois preenchemos o vínculo completo.
            self.api.put(
                f"/cards/{card['id']}",
                {"values": [{"field_id": fields["caso_vinculado"]["id"], "value": ""}]},
            )
            case_value = json.dumps({"record_id": case_record_id, "title": case_title}, ensure_ascii=False)
            self.api.put(
                f"/cards/{card['id']}",
                {
                    "database_id": cases_database_id,
                    "database_ids": [cases_database_id],
                    "record_links": [{"database_id": cases_database_id, "record_id": case_record_id}],
                    "values": [
                        {"field_id": fields["caso_vinculado"]["id"], "value": case_value},
                    ],
                },
            )
            self.actions.append("Caso fictício vinculado ao card por atualização")
        for _ in range(8):
            current = unwrap_data(self.api.get(f"/cards/{card['id']}"))
            if current.get("phase_id") == phases["Em análise pela IA"]["id"]:
                self.actions.append("Automação de vínculo comprovada por movimento real")
                return current
            time.sleep(1)
        raise InstallError(
            "O card de teste foi criado, mas não chegou a 'Em análise pela IA'. "
            "Confira o log da automação no Infinitum; o card foi preservado para diagnóstico."
        )


def resolve_token(args: argparse.Namespace) -> str:
    token = os.getenv("INFINITUM_PUBLIC_TOKEN", "").strip()
    if token:
        return token
    if args.token_file:
        path = Path(args.token_file).expanduser()
        if not path.is_file():
            raise InstallError(f"Arquivo de token não encontrado: {path}")
        token = path.read_text(encoding="utf-8").strip()
        if token:
            return token
    if sys.stdin.isatty():
        return getpass.getpass("Cole o Public Token do Infinitum (entrada oculta): ").strip()
    raise InstallError(
        "Token ausente. O agente deve definir INFINITUM_PUBLIC_TOKEN apenas no ambiente do processo "
        "ou usar --token-file com arquivo local protegido e não versionado."
    )


def public_result(context: InstallContext, installer: Installer, manifest: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": "aprovado",
        "package_version": manifest["version"],
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "organization": {"id": context.organization["id"], "name": context.organization.get("name")},
        "cases_database": {"id": context.cases_database["id"], "name": context.cases_database.get("name")},
        "pop": {"id": context.pop["id"], "name": context.pop.get("name")},
        "phases": {name: item["id"] for name, item in context.phases.items()},
        "fields": {
            key: {"id": item["id"], "field_id": item.get("field_id"), "label": item.get("label")}
            for key, item in context.fields.items()
        },
        "automations": {key: item.get("id") for key, item in context.automations.items()},
        "test_card": {"id": context.test_card["id"], "phase_id": context.test_card.get("phase_id")}
        if context.test_card
        else None,
        "protocol_is_manual": True,
        "actions": installer.actions,
        "kanban_url": f"https://crm.infinitum.app.br/pops/kanban?pop_id={context.pop['id']}",
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Instala e valida a Esteira de Petições no Infinitum.")
    parser.add_argument("--token-file", default="", help="Arquivo local protegido contendo somente o Public Token.")
    parser.add_argument("--organization-id", default="")
    parser.add_argument("--organization-name", default="")
    parser.add_argument("--casos-database-id", default="")
    parser.add_argument("--pop-name", default="")
    parser.add_argument("--automation-prefix", default="[ESTEIRA]")
    parser.add_argument("--verify-only", action="store_true", help="Somente lê e valida; não cria nem atualiza.")
    parser.add_argument("--test-case-record-id", default="", help="Registro fictício de Casos para teste ponta a ponta.")
    parser.add_argument("--test-case-title", default="Caso fictício da instalação")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        token = resolve_token(args)
        if not token:
            raise InstallError("Token vazio.")
        api = InfinitumAPI(manifest["api_base"], token)
        installer = Installer(
            api,
            manifest,
            organization_id=args.organization_id,
            organization_name=args.organization_name,
            cases_database_id=args.casos_database_id,
            pop_name=args.pop_name,
            automation_prefix=args.automation_prefix,
            verify_only=args.verify_only,
        )
        context = installer.run(args.test_case_record_id, args.test_case_title)
        result = public_result(context, installer, manifest)
        output = Path(args.output).expanduser().resolve()
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("✅ INSTALAÇÃO APROVADA")
        print(f"Organização: {result['organization']['name']}")
        print(f"Procedimento: {result['pop']['name']} ({result['pop']['id']})")
        print(f"Cadastro Casos: {result['cases_database']['id']}")
        print(f"Fases: {len(result['phases'])} | Campos: {len(result['fields'])} | Automações: {len(result['automations'])}")
        print("Protocolo: manual, separado da aprovação jurídica")
        print(f"Relatório sem credenciais: {output}")
        return 0
    except InstallError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        return exc.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
