# Instalador da Esteira de Petições — Infinitum

Este ZIP foi feito para ser entregue diretamente ao Codex CLI ou Claude Code.
O agente configura a conta, cria um teste sintético e comprova o resultado sem o
aluno editar arquivos ou montar o procedimento na mão.

## Prompt para enviar junto com o ZIP

> Descompacte este arquivo e assuma a responsabilidade pela instalação. Leia
> integralmente AGENTS.md se estiver no Codex ou CLAUDE.md se estiver no Claude
> Code, além de INSTRUCOES_AGENTE.md. Instale a Esteira de Petições na minha
> conta do Infinitum, use somente dados fictícios nos testes, não apague nada e
> só conclua depois de gerar resultado_instalacao.json com status aprovado.

## Pré-requisito inevitável

A conta precisa estar aberta e autenticada em um navegador que o agente consiga
controlar. Alternativamente, o Public Token pode estar disponível em secret
store local. O ZIP nunca contém credenciais.

## O que o pacote faz

- reutiliza `Casos` e o procedimento quando já existem;
- cria somente fases e campos ausentes;
- cria ou converge as duas automações para a configuração validada;
- preserva protocolo manual e revisão humana;
- pode criar um card sintético e provar seu movimento automático;
- é idempotente: uma segunda execução não duplica a estrutura;
- nunca executa DELETE nem arquiva dados.

Este pacote instala a estrutura e os gates do Infinitum. A geração efetiva das
minutas continua dependendo do agente/worker jurídico escolhido pelo escritório.
Além disso, a marcação visual de campo obrigatório do Infinitum não é uma trava
contra arraste manual; o worker deve recusar qualquer card sem vínculo com `Casos`.
O arquivo `CONTRATO_DO_WORKER.md` contém a máquina de estados e o payload do
vínculo bidirecional para essa segunda camada.

## Comandos para auditoria técnica

```bash
python3 -m unittest discover -s tests -v
python3 instalar.py --verify-only
```

O instalador usa apenas Python 3 e a API pública do Infinitum. Se a instalação
local do Python não tiver certificados raiz, ele recorre ao `curl` sem desligar
a validação TLS e remove imediatamente os arquivos temporários de credencial.
