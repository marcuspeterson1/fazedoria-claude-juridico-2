# Contrato do worker da Esteira

O instalador prepara o Infinitum. O worker jurídico — n8n, serviço Python,
Claude/Codex agendado ou outro orquestrador — usa os IDs gravados em
`resultado_instalacao.json` e respeita este fluxo.

```text
Entrada validada
  └─ preencher Caso vinculado
       └─ automação nativa → Em análise pela IA
            ├─ faltam documentos → Bloqueada
            └─ insumos suficientes → Em produção pela IA
                   └─ gerar Google Doc e versão → Revisão humana
                          ├─ CORRIGIR → Refação pela IA → Revisão humana
                          ├─ DÚVIDA/PENDENTE → não agir
                          └─ APROVADA → Aprovada para protocolo
                                                └─ protocolo humano
                                                     → Protocolada (manual)
```

## Regras mecânicas

1. Recuse qualquer card sem `Caso vinculado`, mesmo que alguém o tenha arrastado.
2. Use `ID externo / idempotência` para impedir petições duplicadas.
3. A rodada de revisão é `card_id + versão da minuta + revisado_em`.
4. Só grave `feedback_processado_em` depois de criar e reler a nova minuta.
5. Consuma `Decisão da revisão` e `Orientações do revisor`; comentários livres
   não têm endpoint público estável e não são fonte de verdade.
6. Não mova automaticamente para `Protocolada (manual)`.
7. O protocolo exige ação humana e link do comprovante.

## Vínculo bidirecional do card

Ao criar ou atualizar um card, envie conjuntamente:

```json
{
  "database_id": "ID_DO_CADASTRO_CASOS",
  "database_ids": ["ID_DO_CADASTRO_CASOS"],
  "record_links": [
    {"database_id": "ID_DO_CADASTRO_CASOS", "record_id": "ID_DO_CASO"}
  ],
  "values": [
    {
      "field_id": "ID_REAL_DO_CAMPO_CASO_VINCULADO",
      "value": "{\"record_id\":\"ID_DO_CASO\",\"title\":\"Nome do caso\"}"
    }
  ]
}
```

O valor do campo `database` é uma string JSON. `record_links` é o que permite ao
registro de `Casos` apresentar os cards relacionados.
