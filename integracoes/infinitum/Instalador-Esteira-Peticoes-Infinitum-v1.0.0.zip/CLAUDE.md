# Claude Code — instalador da Esteira no Infinitum

Leia integralmente `INSTRUCOES_AGENTE.md` e execute até obter a instalação
aprovada. Este pacote autoriza criar estruturas e dados sintéticos necessários
na conta indicada, mas nunca apagar estruturas existentes nem usar dados reais
de clientes nos testes.
