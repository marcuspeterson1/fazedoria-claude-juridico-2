import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from instalar import Installer, InstallError, NeedsUI, public_result  # noqa: E402


MANIFEST = json.loads((ROOT / "manifesto.json").read_text(encoding="utf-8"))


class FakeAPI:
    def __init__(self, *, with_cases=True):
        self.calls = []
        self.org = {"id": "org-1", "name": "Escritório Teste"}
        self.databases = [{"id": "db-clients", "name": "Clientes"}]
        if with_cases:
            self.databases.insert(0, {"id": "db-cases", "name": "Casos"})
        self.database_fields = []
        for index, spec in enumerate(MANIFEST["cases_database"]["fields"], start=1):
            item = {
                "id": f"dbf-{index}",
                "label": spec["label"],
                "type": spec["type"],
                "required": spec["required"],
            }
            if spec["type"] == "select":
                item["options"] = {"options": spec["options"]}
            elif spec["type"] == "database":
                item["options"] = {"linked_database_id": "db-clients", "allow_multiple": False}
            self.database_fields.append(item)
        self.pops = []
        self.phases = []
        self.fields = []
        self.automations = []
        self.cards = []

    def get(self, path):
        self.calls.append(("GET", path, None))
        if path == "/organizations/my":
            return [self.org]
        if path.startswith("/databases?"):
            return {"data": self.databases}
        if path.startswith("/database-fields?"):
            return {"data": self.database_fields}
        if path.startswith("/organizations/") and "/pops" in path:
            return {"data": self.pops}
        if path.startswith("/pops/") and path.endswith("/phases"):
            return {"data": self.phases}
        if path.startswith("/pop-fields/by-pop?"):
            return {"data": self.fields}
        if path.startswith("/pop-automations?"):
            return {"data": self.automations}
        if path.startswith("/pop-automations/"):
            automation_id = path.split("/")[2].split("?")[0]
            return {"data": next(item for item in self.automations if item["id"] == automation_id)}
        if path.startswith("/cards?"):
            return {"data": self.cards}
        if path.startswith("/cards/"):
            card_id = path.split("/")[-1]
            return {"data": next(item for item in self.cards if item["id"] == card_id)}
        raise AssertionError(f"GET inesperado: {path}")

    def post(self, path, body):
        self.calls.append(("POST", path, body))
        if path.startswith("/organizations/") and path.endswith("/pops"):
            item = {"id": "pop-1", **body}
            self.pops.append(item)
            return {"data": item}
        if path.startswith("/pops/") and path.endswith("/phases"):
            item = {"id": f"phase-{len(self.phases) + 1}", **body}
            self.phases.append(item)
            return {"data": item}
        if path == "/pop-fields":
            item = {"id": f"field-{len(self.fields) + 1}", **body}
            self.fields.append(item)
            return {"data": item}
        if path == "/pop-automations":
            item = {"id": f"automation-{len(self.automations) + 1}", **body}
            self.automations.append(item)
            return {"data": item}
        if path == "/cards":
            item = {"id": "card-test", **body}
            self.cards.append(item)
            return {"data": item}
        raise AssertionError(f"POST inesperado: {path}")

    def put(self, path, body):
        self.calls.append(("PUT", path, body))
        if path.startswith("/cards/"):
            card_id = path.split("/")[-1]
            item = next(item for item in self.cards if item["id"] == card_id)
            item.update({key: value for key, value in body.items() if key != "values"})
            if any(value.get("value") for value in body.get("values", [])):
                item["phase_id"] = self._phase_id("Em análise pela IA")
            return {"data": item}
        automation_id = path.split("/")[-1]
        item = next(item for item in self.automations if item["id"] == automation_id)
        item.update(body)
        return {"data": item}

    def _phase_id(self, name):
        return next(item["id"] for item in self.phases if item["name"] == name)


class InstallerTests(unittest.TestCase):
    def make_installer(self, api, **kwargs):
        return Installer(api, MANIFEST, **kwargs)

    def test_creates_complete_structure_without_delete(self):
        api = FakeAPI()
        installer = self.make_installer(api)
        context = installer.run()
        self.assertEqual(8, len(context.phases))
        self.assertEqual(15, len(context.fields))
        self.assertEqual(2, len(context.automations))
        self.assertFalse(any(method == "DELETE" for method, _, _ in api.calls))
        case_field = context.fields["caso_vinculado"]
        self.assertTrue(case_field["required"])
        self.assertEqual("db-cases", case_field["options"]["database_id"])

    def test_second_run_is_idempotent(self):
        api = FakeAPI()
        self.make_installer(api).run()
        first_post_count = sum(method == "POST" for method, _, _ in api.calls)
        self.make_installer(api).run()
        second_post_count = sum(method == "POST" for method, _, _ in api.calls)
        self.assertEqual(first_post_count, second_post_count)

    def test_requires_browser_when_cases_database_is_missing(self):
        with self.assertRaises(NeedsUI):
            self.make_installer(FakeAPI(with_cases=False)).run()

    def test_verify_only_does_not_mutate(self):
        api = FakeAPI()
        self.make_installer(api).run()
        api.calls.clear()
        context = self.make_installer(api, verify_only=True).run()
        self.assertEqual(15, len(context.fields))
        self.assertFalse(any(method in {"POST", "PUT", "DELETE"} for method, _, _ in api.calls))

    def test_incompatible_required_field_stops_without_duplicate(self):
        api = FakeAPI()
        self.make_installer(api).run()
        case_field = next(item for item in api.fields if item["label"] == "Caso vinculado (obrigatório)")
        case_field["required"] = False
        posts_before = sum(method == "POST" for method, _, _ in api.calls)
        with self.assertRaises(InstallError):
            self.make_installer(api).run()
        posts_after = sum(method == "POST" for method, _, _ in api.calls)
        self.assertEqual(posts_before, posts_after)

    def test_test_card_has_bidirectional_case_link(self):
        api = FakeAPI()
        context = self.make_installer(api).run("case-1", "Caso fictício")
        card_create = next(body for method, path, body in api.calls if method == "POST" and path == "/cards")
        self.assertNotIn("database_id", card_create)
        link_call = next(
            body
            for method, path, body in api.calls
            if method == "PUT" and path == "/cards/card-test" and body.get("database_id")
        )
        self.assertEqual("db-cases", link_call["database_id"])
        self.assertEqual([{"database_id": "db-cases", "record_id": "case-1"}], link_call["record_links"])
        self.assertEqual(api._phase_id("Em análise pela IA"), context.test_card["phase_id"])


if __name__ == "__main__":
    unittest.main()
