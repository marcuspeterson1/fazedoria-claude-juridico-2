# Instruções obrigatórias para o agente instalador

Sua responsabilidade é instalar e comprovar a Esteira de Petições na conta do
Infinitum do usuário. O usuário não deve editar arquivos, executar comandos ou
montar fases e campos manualmente.

## Resultado esperado

Ao terminar, a conta deve conter:

- cadastro `Casos` com os 12 campos de `manifesto.json`;
- procedimento `Esteira de Petições — IA + Revisão Humana`;
- oito fases e quinze campos estruturados;
- automação do vínculo com `Casos` para `Em análise pela IA`;
- automação que cria tarefa humana ao entrar em `Revisão humana`;
- teste sintético comprovando o movimento automático;
- `resultado_instalacao.json` sem token, senha ou cookie.

## Regras de execução

1. Leia `manifesto.json`, `GUIA_AGENTE_CADASTRO_CASOS.md`,
   `CONTRATO_DO_WORKER.md` e `instalar.py` antes de agir.
2. Não apague nem arquive cadastros, procedimentos, campos, cards ou automações.
3. Não coloque token em comando, documentação, chat, log ou arquivo versionado.
4. Obtenha o Public Token pela sessão já autenticada do navegador. Mantenha-o
   somente no ambiente do processo ou em arquivo temporário com permissão `0600`,
   removido logo após o uso.
5. Rode primeiro `python3 instalar.py`. Os códigos especiais são:
   - `20`: use a interface para criar/completar `Casos`, depois rode novamente;
   - `21`: escolha a organização/cadastro indicado e rode com o ID explícito.
6. Se `Casos` precisar de configuração, faça você mesmo pela interface seguindo
   o guia. Não peça ao aluno para clicar ou digitar campos.
7. Crie um cliente e um caso apenas com dados obviamente fictícios se não houver
   registro sintético disponível. Nunca use dados reais para validar a instalação.
8. Execute novamente com `--test-case-record-id ID --test-case-title "Caso fictício da instalação"`.
9. Rode os testes locais e a verificação somente-leitura antes de concluir:
   `python3 -m unittest discover -s tests -v` e `python3 instalar.py --verify-only`.
10. Só declare sucesso se o instalador imprimir `INSTALAÇÃO APROVADA`, o card de
    teste estiver em `Em análise pela IA` e o protocolo continuar manual.

## Limites jurídicos

- A IA prepara e refaz minutas; advogado humano aprova.
- Aprovação jurídica não significa protocolo.
- `Protocolada (manual)` só recebe card após ação humana e comprovante.
- Não invente prazo, documento, movimento ou conteúdo processual ausente.

## Entrega ao usuário

Informe de forma curta: organização instalada, link do procedimento, quantidade
de fases/campos/automações, ID do card sintético e resultado dos testes. Não
revele o Public Token.
